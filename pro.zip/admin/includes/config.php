<?php
$con=mysqli_connect("localhost","root","","spice_ecom");
?>