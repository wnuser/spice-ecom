<?php
session_start();
session_unset();
?>
<script language="javascript">
document.location="index.php";
</script>